Global Gladiators (Game Gear)
Traducción al Español v1.0 (14/02/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Global Gladiators (Europe).gg
MD5: d3a436b1fb64fd6295a30cc12ba6bed9
SHA1: ddad863406d429acb218c75042d5e5c511bdad4f
CRC32: d2b6021e
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --