The Lucky Dime Caper Starring Donald Duck (Master System)
Traducción al Español v1.0 (07/12/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Lucky Dime Caper Starring Donald Duck, The (Europe, Brazil).sms
MD5: 653f10042a5ee5854ccf971456641a4d
SHA1: a08815d27e431f0bee70b4ebfb870a3196c2a732
CRC32: a1710f13
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --