Desert Speedtrap Starring Road Runner and Wile E. Coyote (Master System)
Traducción al Español v1.0 (07/12/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Desert Speedtrap Starring Road Runner and Wile E. Coyote (Europe, Brazil) (En,Fr,De,Es,It).sms
MD5: 8fe55ade7b34aa4e42c5f63f4368497f
SHA1: 60e2b6ec69d73dd73c1ef846634942c81800655b
CRC32: b137007a
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --